﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$.TestData
{
    public class TestSource
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

}