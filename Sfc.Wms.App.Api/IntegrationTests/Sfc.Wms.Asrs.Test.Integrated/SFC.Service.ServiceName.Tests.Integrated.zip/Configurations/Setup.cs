﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestStack.BDDfy.Configuration;
using TestStack.BDDfy.Reporters.Html;

namespace $safeprojectname$.Configurations
{
    [TestClass]
    public class Setup
    {
        [AssemblyInitialize]
        public static void ApplyBddFyReportConfiguration(TestContext testContext)
        {
            ApplyBddFyReportConfiguration();
        }

        private static void ApplyBddFyReportConfiguration()
        {
            Configurator.BatchProcessors.HtmlReport.Disable();

            //Configure your test namespace to check the BDDFY report.
            Configurator.BatchProcessors.Add(new HtmlReporter(new HtmlReportConfig("UnitTesting",
                "Sfc_Service_ServiceName_Test_Unit.html", "Sfc.Service.ServiceName.Test.Unit.Controllers", "Sfc WMS Tests",
                "Sfc WMS Scenarios and their Test Results")));
        }
    }
}