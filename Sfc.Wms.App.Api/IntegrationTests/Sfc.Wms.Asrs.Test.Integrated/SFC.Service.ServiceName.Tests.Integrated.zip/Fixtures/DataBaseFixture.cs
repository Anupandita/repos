﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Configuration;
using System.Data;
using Oracle.ManagedDataAccess.Client;

namespace $safeprojectname$.Fixtures
{
    public class DataBaseFixture
    {
        public DataTable Dt = new DataTable();
        public void GetDataFromDb()
        {
            OracleConnection db;
            using (db = new OracleConnection
            {
                ConnectionString = ConfigurationManager.ConnectionStrings["Model1"].ConnectionString
            })
            {
                db.Open();
                var sql1 = $"select * from <TableName> where <FieldName> ='Case' AND <FieldName>=7 AND <FieldName> = 0";
                var command = new OracleCommand(sql1, db);
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // <FieldName> = reader[0].ToString();
                    }
                }
            }
        }
    }
}
