﻿using System;
using System.Net.Http;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using $safeprojectname$.TestData;
using System.Threading.Tasks;
using System.Linq;
using System.Diagnostics;
using Humanizer;
using System.Web;

namespace $safeprojectname$.Fixtures
{
    // <summary>
    // This fixture class is the base class for all tests.
    // </summary>
    public abstract class WmsFixture
    {
        protected TestSource TestMatchingSource;
        protected string baseUrl = "http://localhost/api/ModuleName";

        protected void GivenAValidNewRecord()
        {
            //Initialization of required objects
            //Example:
            TestMatchingSource = new TestSource
            {
                Id = 1,
                Name = "Name",

            };
        }

        protected void GetServiceNameIsCalled()
        {
            //Example:
            /*var client = new HttpClient();
            var task = await client.GetAsync(baseUrl);
            var jsonstring = await task.Content.ReadAsStringAsync();
            var serializer = new JavaScriptSerializer();
            var model = serializer.Deserialize<List<ClassNameModel>>(jsonstring);          
            Debug.Print(model.Count.ToString());*/
        }

        protected void OkIsReturned()
        {
            //Example:
            //Assert.AreEqual(HttpStatusCode.OK, ReturnedValue);
        }

        protected void CreateServiceNameIsCalled()
        {
            //throw new NotImplementedException();
        }

        protected void CreatedIsReturned()
        {
            //throw new NotImplementedException();
        }

        protected void UpdateServiceNameIsCalled()
        {
            throw new NotImplementedException();
        }

        protected void NoContentIsReturned()
        {
            throw new NotImplementedException();
        }

        protected void DeleteServiceNameIsCalled()
        {

        }

        protected void StringBuilderTest()
        {
            //Example for String builder
            var querystringParams = new[] {
             new {key = $"{nameof(TestMatchingSource.Id)}", value = "casey" },
             new {key = $"{nameof(TestMatchingSource.Name)}",value = "20"},
            };
            var encodedQueryStringParams = querystringParams.Select(p => string.Format("{0}={1}", p.key, HttpUtility.UrlEncode(p.value)));
            UriBuilder builder = new UriBuilder(baseUrl); builder.Query = string.Join("&", encodedQueryStringParams);
            var ServiceNameUrl = builder.ToString();
            /*using (var client = new HttpClient())
            {
                var response = await client.DeleteAsync(
                    ServiceNameUrl
                );*/
            Debug.Print(ServiceNameUrl);
        }

        protected void StringInterpolationTest()
        {
            //Example for String Interpolation in urls
            // $"{baseUrl}?{nameof(ObjectName.FieldName)}={ObjectName.FieldName}&{nameof(ObjectName.FieldName)}={TestMatchingPut.BRCD_LEN}}"
            var StringInterpolationurl = $"{baseUrl}?{nameof(TestMatchingSource.Id)}={"1"}&{nameof(TestMatchingSource.Id)}={"7"}&{nameof(TestMatchingSource.Name)}={"case"}";
            Debug.Print(StringInterpolationurl);
        }

        protected void Camelize()
        {
            //Example for Camelizing the left side values
            //(<ObjectName>.<FieldName>) = $"{nameof(<ObjectName>.<FieldName>).Camelize}
            TestMatchingSource.Name = $"{nameof(TestMatchingSource.Name).Camelize()}";
            Debug.Print(TestMatchingSource.Name);
        }
    }
}
