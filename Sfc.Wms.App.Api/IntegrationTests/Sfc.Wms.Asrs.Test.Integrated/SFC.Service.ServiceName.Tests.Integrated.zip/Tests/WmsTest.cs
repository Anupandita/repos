﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using $safeprojectname$.Fixtures;
using System;
using TestStack.BDDfy;

namespace $safeprojectname$.WmsTests
{
    [TestClass]
    [Story(
        AsA = "",
        IWant = "",
        SoThat = ""
        )]
    public class WmsTest : WmsFixture
    {
        //Examples:

        [TestMethod()]
        [TestCategory("FUNCTIONAL")]
        public void CreateNewRecord()
        {
            this.Given(x => x.GivenAValidNewRecord())
                 .When(x => x.CreateServiceNameIsCalled())
                 .Then(x => x.CreatedIsReturned())
                 .BDDfy();
        }

        [TestMethod()]
        public void StringTest()
        {
            this.Given(t => t.StringBuilderTest())
                .And(t => t.StringInterpolationTest())
                .BDDfy();
        }



    }
}
